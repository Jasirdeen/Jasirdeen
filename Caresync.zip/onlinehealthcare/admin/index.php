<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Caresync</title>
    <meta charset="utf-8" />
    <link rel="shortcut icon" href="../images/logo.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="../css/customize.css" />
    <style>
        /* Add a light green background */
        body {
            background-color: #d0f0c0;
        }

        /* Styling for animated health tips with slow motion effect */
        .health-tips {
            font-size: 18px;
            font-weight: bold;
            color: #2d3436;
            text-align: center;
            padding: 10px;
            margin-top: 20px;
        }

        .health-tips p {
            animation: fade 50s infinite; /* Slow down the animation by increasing duration */
            opacity: 0;
        }

        @keyframes fade {
            0%, 100% {
                opacity: 0;
            }
            10%, 90% {
                opacity: 1;
            }
        }

        /* Box for app information */
        .app-info-box {
            background-color: #ffffff;
            border: 2px solid #2d3436;
            border-radius: 10px;
            padding: 20px;
            margin: 20px auto;
            width: 80%;
            text-align: center;
            font-size: 20px;
            font-weight: bold;
            color: #2d3436;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="navbar navbar-default">
        <img src="../images/Caresync logo.png" style="float:left;" height="55px" />
        <label class="navbar-brand">Caresync</label>
    </div>

    <div id="top" class="login">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <center><h1 class="panel-title">Administrator</h1></center>
            </div>
            <div class="panel-body">
                <form enctype="multipart/form-data" action="login.php" role="form" method="POST">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input class="form-control" name="username" placeholder="Username" type="text" required="required">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input class="form-control" name="password" placeholder="Password" type="password" required="required">
                    </div>
                    <div class="form-group">
                        <button class="btn btn-block btn-success" name="login"><span class="glyphicon glyphicon-log-in"></span> Login</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Box displaying app information -->
    <div class="app-info-box">
        Caresync, your personified health recorder.
    </div>


    <div id="footer">
        <label class="footer-title">&copy; Copyright Caresync@2024</label>
    </div>
</body>

<?php
    include("script.php");
?>
<script type="text/javascript">
    $(document).ready(function() {
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
    });
</script>
</html>
